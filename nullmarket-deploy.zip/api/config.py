import os, json
from http.server import BaseHTTPRequestHandler

DEFAULTS = {
    'merchant_name': 'NullMarket Digital Services',
    'gcash_number': '+63 917 555 0123',
    'maya_number': '+63 918 555 0123',
}

class handler(BaseHTTPRequestHandler):
    def _send(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self._send({
            'merchant_name': os.environ.get('MERCHANT_NAME', DEFAULTS['merchant_name']),
            'gcash_number': os.environ.get('GCASH_NUMBER', DEFAULTS['gcash_number']),
            'maya_number': os.environ.get('MAYA_NUMBER', DEFAULTS['maya_number']),
            'smtp_configured': bool(os.environ.get('SMTP_USER') and os.environ.get('SMTP_PASS')),
            'mode': 'vercel-serverless',
        })
