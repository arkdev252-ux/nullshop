"""POST /api/orders -> records the order (email notification) and confirms it."""
import os, json, smtplib
from http.server import BaseHTTPRequestHandler
from email.message import EmailMessage

class handler(BaseHTTPRequestHandler):
    def _send(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        n = int(self.headers.get('Content-Length', 0))
        try:
            order = json.loads(self.rfile.read(n).decode()) if n else {}
        except Exception:
            return self._send({'ok': False, 'error': 'Invalid JSON'}, 400)

        # notify the merchant (optional - set SMTP_USER/SMTP_PASS and MERCHANT_EMAIL)
        user = os.environ.get('SMTP_USER', '')
        pwd = os.environ.get('SMTP_PASS', '')
        merchant = os.environ.get('MERCHANT_EMAIL', user)
        notified = False
        if user and pwd and merchant:
            try:
                msg = EmailMessage()
                msg['Subject'] = f"New order {order.get('id')} - {order.get('methodLabel')} ${order.get('total')}"
                msg['From'] = f"NullMarket Orders <{user}>"
                msg['To'] = merchant
                msg.set_content(json.dumps(order, indent=2))
                with smtplib.SMTP('smtp.gmail.com', 587, timeout=25) as s:
                    s.starttls(); s.login(user, pwd); s.send_message(msg)
                notified = True
            except Exception:
                pass

        return self._send({'ok': True, 'order': order, 'merchant_notified': notified,
                           'files': [{'pid': i.get('pid'), 'url': '/api/download'} for i in order.get('items', [])]})
