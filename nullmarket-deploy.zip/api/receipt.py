"""POST /api/receipt  -> sends a REAL receipt email via Gmail SMTP (env SMTP_USER / SMTP_PASS)."""
import os, json, time, smtplib
from http.server import BaseHTTPRequestHandler
from email.message import EmailMessage

def email_html(order, base_url):
    rows = ''
    for it in order.get('items', []):
        url = f"{base_url}/?download={order.get('id')}:{it.get('pid')}"
        rows += (
            '<div style="background:#f1f3f4;border-radius:10px;padding:14px 16px;margin:8px 0;display:flex;'
            'align-items:center;gap:12px"><div style="flex:1">'
            f'<b style="font-size:14px;color:#202124">{it.get("name")}</b>'
            f'<div style="font-size:11.5px;color:#5f6368;margin-top:2px">v{it.get("version")} &middot; '
            f'License attached &middot; Qty {it.get("qty", 1)}</div></div>'
            f'<a href="{url}" style="background:#1a73e8;color:#fff;text-decoration:none;padding:11px 20px;'
            'border-radius:8px;font-weight:700;font-size:13px">Download Now</a></div>'
        )
    return (
        '<div style="font-family:Arial,Helvetica,sans-serif;max-width:560px;margin:0 auto">'
        '<div style="font-size:18px;font-weight:700;color:#202124;padding:16px 0">'
        'Payment successful - here is your item</div>'
        '<div style="background:#e6f4ea;color:#137333;border-radius:10px;padding:14px 16px;font-weight:700;'
        f'font-size:13.5px">✓ Payment successful! ${order.get("total")} paid via {order.get("methodLabel")}</div>'
        f'<p style="font-size:13.5px;color:#3c4043;line-height:1.6">Hi {order.get("uname", "there")}, '
        'thanks for your purchase! Click <b>Download Now</b> below:</p>'
        f'{rows}'
        f'<p style="font-size:11px;color:#5f6368;margin-top:18px">Order {order.get("id")} &middot; '
        'Sent by NullMarket</p></div>'
    )

class handler(BaseHTTPRequestHandler):
    def _send(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        n = int(self.headers.get('Content-Length', 0))
        try:
            body = json.loads(self.rfile.read(n).decode()) if n else {}
        except Exception:
            return self._send({'ok': False, 'error': 'Invalid JSON'}, 400)

        order = body.get('order', {})
        to = body.get('to') or order.get('email', '')
        if not to:
            return self._send({'ok': False, 'error': 'Missing recipient'}, 400)

        base_url = body.get('base_url', '')
        user = os.environ.get('SMTP_USER', '')
        pwd = os.environ.get('SMTP_PASS', '')

        msg = EmailMessage()
        msg['Subject'] = 'Payment successful - here is your item'
        msg['From'] = f"{os.environ.get('MERCHANT_NAME', 'NullMarket')} <{user or 'receipts@nullmarket.local'}>"
        msg['To'] = to
        text = (f"Payment successful! ${order.get('total')} paid via {order.get('methodLabel')}.\n\n"
                f"Order: {order.get('id')}\n\nYour items: "
                + ', '.join(f"{i.get('name')} v{i.get('version')}" for i in order.get('items', [])))
        msg.set_content(text)
        msg.add_alternative(email_html(order, base_url), subtype='html')

        if user and pwd:
            try:
                with smtplib.SMTP('smtp.gmail.com', 587, timeout=25) as s:
                    s.starttls()
                    s.login(user, pwd)
                    s.send_message(msg)
                return self._send({'ok': True, 'sent': True, 'transport': 'gmail-smtp'})
            except Exception as e:
                return self._send({'ok': True, 'sent': False, 'transport': 'smtp-error: ' + str(e)})
        return self._send({'ok': True, 'sent': False, 'transport': 'smtp-not-configured'})
