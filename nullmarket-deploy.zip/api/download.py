"""POST /api/download -> builds a REAL .zip delivery package in memory and returns it."""
import io, re, json, zipfile, hashlib
from http.server import BaseHTTPRequestHandler

LINE = '=' * 64

def slugify(name):
    s = re.sub(r'[^a-z0-9]+', '-', str(name).lower()).strip('-')
    return s[:42] or 'product'

def build_files(order, item):
    version = str(item.get('version', '1.0'))
    name = item.get('name', 'Product')
    pid = item.get('pid', 0)
    license_key = ('NM-' + str(order.get('id', 'ORDER'))[3:] + '-' + str(pid).zfill(4) + '-'
                   + hashlib.md5((str(order.get('id')) + name).encode()).hexdigest()[:12].upper())
    meta = item.get('meta', {})
    howto = [re.sub(r'<[^>]+>', '', h) for h in meta.get('howto', ['Download and unpack this package.', 'Follow the documentation.'])]
    reqs = meta.get('reqs', ['Valid license key'])
    changelog = meta.get('changelog', [{'version': version, 'date': order.get('date', 'Today'), 'notes': ['Current stable release']}])

    readme = '\n'.join([LINE, ' NullMarket - Digital Delivery Package', LINE, '',
        f' Product    : {name}', f' Version    : {version} (latest, auto-updated)',
        f' Order      : {order.get("id")}', f' License    : {license_key}',
        f' Licensed to: {order.get("email")}', f' Purchased  : {order.get("date")}',
        f' Paid via   : {order.get("methodLabel")} ({order.get("total")})', '',
        ' Payment successful - here is your item!', '',
        ' Files in this package:', '   README.txt', '   LICENSE.txt', '   INSTALL.txt', '   CHANGELOG.txt', '', LINE])
    license_txt = '\n'.join([LINE, ' NullMarket License Certificate', LINE, '',
        f' License key  : {license_key}', f' Product      : {name} v{version}',
        f' Licensed to  : {order.get("email")}', ' Type         : Commercial use license',
        ' Updates      : Included - re-download anytime for new versions', '', LINE])
    install = '\n'.join([LINE, f' How to use / install - {name} v{version}', LINE, ''] +
        [f' {i+1}. {h}' for i, h in enumerate(howto)] +
        ['', ' Requirements:'] + [f'   - {r}' for r in reqs] + ['', LINE])
    cl = [LINE, f' Changelog - {name}', LINE, '']
    for c in changelog:
        cl += [f' v{c.get("version")}  ({c.get("date", "")})'] + [f'   - {n}' for n in c.get('notes', [])] + ['']
    cl.append(LINE)
    receipt = '\n'.join([LINE, f' Order Receipt {order.get("id")}', LINE, '',
        f' Date : {order.get("date")}', f' Email: {order.get("email")}',
        f' Method: {order.get("methodLabel")} {order.get("paidText", "")}',
        f' Total: ${order.get("total")}', '', LINE])
    return {
        'README.txt': readme, 'LICENSE.txt': license_txt, 'INSTALL.txt': install,
        'CHANGELOG.txt': '\n'.join(cl), f'ORDER-{order.get("id")}.txt': receipt,
    }

class handler(BaseHTTPRequestHandler):
    def do_POST(self):
        n = int(self.headers.get('Content-Length', 0))
        try:
            body = json.loads(self.rfile.read(n).decode()) if n else {}
        except Exception:
            body = {}
        order = body.get('order', {})
        item = body.get('item', {})
        if not item:
            self.send_response(400); self.end_headers(); self.wfile.write(b'{"error":"missing item"}'); return

        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
            for fname, content in build_files(order, item).items():
                z.writestr(fname, content)
        data = buf.getvalue()
        fname = slugify(item.get('name')) + '-' + str(item.get('version', '1.0')) + '.zip'

        self.send_response(200)
        self.send_header('Content-Type', 'application/zip')
        self.send_header('Content-Disposition', f'attachment; filename="{fname}"')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)
