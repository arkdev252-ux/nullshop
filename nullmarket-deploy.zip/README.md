# NullMarket — Premium Digital Assets Shop

A full e-commerce storefront (Minecraft / XenForo / WordPress / WHMCS / Unity assets) with:

- 🛍️ 65 priced products with real thumbnails, versions, install guides & changelogs
- 💚 GCash / Maya **Send Money** checkout flow (merchant number + reference no.)
- 💳 PayPal · Card · Crypto · Bank options
- 📦 **Real .zip delivery packages** (README + LICENSE key + INSTALL + CHANGELOG)
- ✉️ **Real receipt emails** via Gmail SMTP
- 👤 Accounts, order history, inbox
- 🔄 Auto-updating product versions

---

## 🚀 Deploy on Vercel (2 minutes)

### 1. Push to GitHub

```bash
git init
git add .
git commit -m "NullMarket shop"
```

Create a new repository on [github.com](https://github.com), then:

```bash
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git branch -M main
git push -u origin main
```

### 2. Import to Vercel

1. Go to [vercel.com/new](https://vercel.com/new) → **Import** your GitHub repo
2. Click **Deploy** (zero config — `vercel.json` is already set up)

### 3. Configure Environment Variables (Vercel → Settings → Environment Variables)

| Variable | Purpose | Example |
|---|---|---|
| `MERCHANT_NAME` | Name shown to buyers at checkout | `Juan Dela Cruz` |
| `GCASH_NUMBER` | Your real GCash number | `+63 917 123 4567` |
| `MAYA_NUMBER` | Your real Maya number | `+63 918 123 4567` |
| `SMTP_USER` | Your Gmail address (sender) | `you@gmail.com` |
| `SMTP_PASS` | Gmail **App Password** (16 chars) | `abcd efgh ijkl mnop` |
| `MERCHANT_EMAIL` | Where new-order notifications go | `you@gmail.com` |

> **Gmail App Password:** Google Account → Security → 2-Step Verification → App passwords →
> create one for "Mail". Paste the 16-character password as `SMTP_PASS`.
> With this set, receipts **actually arrive in the buyer's Gmail**.

Redeploy after saving variables (Vercel → Deployments → ⋯ → Redeploy).

---

## 💻 Run locally (full backend, persistent files)

```bash
cp config.example.json config.json   # then edit your numbers / Gmail
python3 server.py                    # http://localhost:8080
```

Local mode adds persistence that serverless lacks:

- `data/orders.json` — real order database
- `data/users.json` — real accounts
- `data/deliveries/<ORDER>/…zip` — generated product packages on disk
- `data/outbox/*.eml` — saved receipt emails

---

## 📁 Project structure

```
├── index.html          # the complete shop (static, works standalone)
├── img/                # product thumbnails + payment logos
├── api/                # Vercel serverless functions
│   ├── config.py       # GET  merchant settings (env vars)
│   ├── receipt.py      # POST real Gmail SMTP receipt emails
│   ├── download.py     # POST builds real .zip delivery packages
│   └── orders.py       # POST order confirmation + merchant notification
├── server.py           # local dev backend (persistence + same APIs)
├── config.example.json # copy to config.json for local dev
├── vercel.json         # Vercel build & routing config
└── requirements.txt    # (stdlib only)
```

## 📦 API endpoints

| Method | Path | Description |
|---|---|---|
| GET | `/api/config` | Merchant name & payment numbers |
| POST | `/api/orders` | Save/confirm an order |
| POST | `/api/receipt` | Send receipt email (Gmail SMTP) |
| POST | `/api/download` | Get the real .zip package for an item |

## ⚙️ Notes

- **Downloads work even without a backend** — if the API is unreachable, the browser
  builds the same .zip package client-side and saves it to the device.
- **Payments**: GCash/Maya use the real-world *Send Money → merchant number → reference no.*
  flow (the buyer's real balance is deducted inside their GCash/Maya app).
- On Vercel Hobby, function invocations are stateless — for a persistent order database,
  add Vercel KV / Upstash and extend `api/orders.py`.

© 2026 NullMarket — product names belong to their respective owners.
