#!/usr/bin/env python3
"""NullMarket REAL backend: static site + real orders + real .zip delivery + Gmail SMTP receipts."""
import json, os, re, io, time, zipfile, smtplib, hashlib, datetime
from http.server import HTTPServer, SimpleHTTPRequestHandler
from email.message import EmailMessage
from urllib.parse import urlparse, unquote

ROOT = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(ROOT, 'data')
DELIV = os.path.join(DATA, 'deliveries')
OUTBOX = os.path.join(DATA, 'outbox')
os.makedirs(DELIV, exist_ok=True)
os.makedirs(OUTBOX, exist_ok=True)

CFG_PATH = os.path.join(ROOT, 'config.json')
USERS_PATH = os.path.join(DATA, 'users.json')
ORDERS_PATH = os.path.join(DATA, 'orders.json')

def jload(p, d):
    try:
        with open(p) as f: return json.load(f)
    except Exception: return d

def jsave(p, v):
    with open(p, 'w') as f: json.dump(v, f, indent=2)

def cfg(): return jload(CFG_PATH, {})
def sha(s): return hashlib.sha256(str(s).encode()).hexdigest()

def slugify(name):
    s = re.sub(r'[^a-z0-9]+', '-', str(name).lower()).strip('-')
    return s[:42] or 'product'

LINE = '=' * 64

def build_item_files(order, item):
    """Return {filename: content} for one product."""
    version = str(item.get('version', '1.0'))
    name = item.get('name', 'Product')
    pid = item.get('pid', 0)
    license_key = 'NM-' + str(order.get('id', 'ORDER'))[3:] + '-' + str(pid).zfill(4) + '-' + hashlib.md5((str(order.get('id')) + name).encode()).hexdigest()[:12].upper()
    meta = item.get('meta', {})
    howto = meta.get('howto', ['Download and unpack this package.', 'Follow the included documentation.', 'Apply your license key where required.'])
    howto = [re.sub(r'<[^>]+>', '', h) for h in howto]
    reqs = meta.get('reqs', ['Valid license key'])
    changelog = meta.get('changelog', [{'version': version, 'date': order.get('date', 'Today'), 'notes': ['Current stable release']}])

    readme = '\n'.join([LINE, ' NullMarket - Digital Delivery Package', LINE, '',
        f' Product    : {name}',
        f' Version    : {version} (latest, auto-updated)',
        f' Order      : {order.get("id")}',
        f' License    : {license_key}',
        f' Licensed to: {order.get("email")}',
        f' Purchased  : {order.get("date")}',
        f' Paid via   : {order.get("methodLabel")} ({order.get("total")})', '',
        ' Payment successful - here is your item!', '',
        ' Files in this package:',
        '   README.txt       - this file',
        '   LICENSE.txt      - your license certificate',
        '   INSTALL.txt      - how to use / install',
        '   CHANGELOG.txt    - full version history',
        f'   ORDER-{order.get("id")}.txt - your receipt', '', LINE])

    license_txt = '\n'.join([LINE, ' NullMarket License Certificate', LINE, '',
        f' License key  : {license_key}',
        f' Product      : {name} v{version}',
        f' Licensed to  : {order.get("email")}',
        ' Type         : Commercial use license',
        ' Updates      : Included - re-download anytime for new versions', '',
        ' Keep this file for your records.', LINE])

    install = '\n'.join([LINE, f' How to use / install - {name} v{version}', LINE, ''] +
        [f' {i+1}. {h}' for i, h in enumerate(howto)] +
        ['', ' Requirements:'] + [f'   - {r}' for r in reqs] + ['', LINE])

    cl_lines = [LINE, f' Changelog - {name}', LINE, '']
    for c in changelog:
        cl_lines += [f' v{c.get("version")}  ({c.get("date", "")})'] + [f'   - {n}' for n in c.get('notes', [])] + ['']
    cl_lines.append(LINE)
    changelog_txt = '\n'.join(cl_lines)

    receipt = '\n'.join([LINE, f' Order Receipt {order.get("id")}', LINE, '',
        f' Date   : {order.get("date")}',
        f' Email  : {order.get("email")}',
        f' Method : {order.get("methodLabel")}  {order.get("paidText", "")}',
        f' Ref    : {order.get("refNo", "")}',
        f' Total  : ${order.get("total")}', '', ' Items:'] +
        [f'   {i.get("qty", 1)}x {i.get("name")}  v{i.get("version", "")}' for i in order.get('items', [])] +
        ['', LINE])

    return {
        'README.txt': readme,
        'LICENSE.txt': license_txt,
        'INSTALL.txt': install,
        'CHANGELOG.txt': changelog_txt,
        f'ORDER-{order.get("id")}.txt': receipt,
    }

def deliver_path(order, item):
    d = os.path.join(DELIV, str(order.get('id')))
    os.makedirs(d, exist_ok=True)
    fname = slugify(item.get('name')) + '-' + str(item.get('version', '1.0')) + '.zip'
    return os.path.join(d, fname), fname

def generate_zip(order, item):
    path, fname = deliver_path(order, item)
    if os.path.exists(path): return path, fname
    files = build_item_files(order, item)
    thumb = item.get('img')
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        for n, c in files.items():
            z.writestr(n, c)
        if thumb and os.path.exists(os.path.join(ROOT, 'img', thumb)):
            z.write(os.path.join(ROOT, 'img', thumb), 'preview-' + thumb)
    return path, fname

def email_html(order, base_url):
    rows = ''
    for it in order.get('items', []):
        url = f"{base_url}/api/deliveries/{order.get('id')}/{it.get('pid')}.zip"
        rows += f'''<div style="background:#f1f3f4;border-radius:10px;padding:14px 16px;margin:8px 0;display:flex;align-items:center;gap:12px">
<div style="flex:1"><b style="font-size:14px;color:#202124">{it.get('name')}</b>
<div style="font-size:11.5px;color:#5f6368;margin-top:2px">v{it.get('version')} &middot; License attached &middot; Qty {it.get('qty',1)}</div></div>
<a href="{url}" style="background:#1a73e8;color:#fff;text-decoration:none;padding:11px 20px;border-radius:8px;font-weight:700;font-size:13px">Download Now</a></div>'''
    return f'''<div style="font-family:Arial,Helvetica,sans-serif;max-width:560px;margin:0 auto">
<div style="font-size:18px;font-weight:700;color:#202124;padding:16px 0">Payment successful - here is your item</div>
<div style="background:#e6f4ea;color:#137333;border-radius:10px;padding:14px 16px;font-weight:700;font-size:13.5px">✓ Payment successful! ${order.get('total')} paid via {order.get('methodLabel')}{(' (' + order.get('paidText') + ')') if order.get('paidText') else ''}.</div>
<p style="font-size:13.5px;color:#3c4043;line-height:1.6">Hi {order.get('uname', 'there')}, thanks for your purchase! Here is your item{'s' if len(order.get('items',[]))>1 else ''} - click <b>Download Now</b> below:</p>
{rows}
<p style="font-size:11px;color:#5f6368;margin-top:18px">Order {order.get('id')} &middot; Ref {order.get('refNo','')} &middot; Sent by NullMarket</p></div>'''

def send_receipt(to, order, base_url):
    c = cfg()
    user = c.get('smtp_user', '')
    pwd = c.get('smtp_pass', '')
    subject = 'Payment successful - here is your item'
    text = f"Payment successful! ${order.get('total')} paid via {order.get('methodLabel')}.\n\nOrder: {order.get('id')}\n\nYour download links:\n" + \
        '\n'.join(f"- {it.get('name')}: {base_url}/api/deliveries/{order.get('id')}/{it.get('pid')}.zip" for it in order.get('items', []))
    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = f"{c.get('merchant_name', 'NullMarket')} <{user or 'receipts@nullmarket.local'}>"
    msg['To'] = to
    msg.set_content(text)
    msg.add_alternative(email_html(order, base_url), subtype='html')
    eml_name = f"{order.get('id')}-{int(time.time())}.eml"
    with open(os.path.join(OUTBOX, eml_name), 'wb') as f:
        f.write(bytes(msg))
    if user and pwd:
        try:
            with smtplib.SMTP('smtp.gmail.com', 587, timeout=25) as s:
                s.starttls()
                s.login(user, pwd)
                s.send_message(msg)
            return {'sent': True, 'transport': 'gmail-smtp', 'eml': eml_name}
        except Exception as e:
            return {'sent': False, 'transport': 'smtp-error: ' + str(e), 'eml': eml_name}
    return {'sent': False, 'transport': 'outbox (add gmail app password in config.json to send real mail)', 'eml': eml_name}


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=ROOT, **kw)

    def log_message(self, fmt, *args):
        print('[http]', args[0] if args else fmt)

    def json_body(self):
        n = int(self.headers.get('Content-Length', 0))
        if n <= 0: return {}
        try:
            return json.loads(self.rfile.read(n).decode('utf-8'))
        except Exception:
            return {}

    def send_json(self, obj, code=200):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(b)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(b)

    def send_file_attachment(self, path, download_name):
        with open(path, 'rb') as f:
            b = f.read()
        self.send_response(200)
        self.send_header('Content-Type', 'application/zip')
        self.send_header('Content-Disposition', f'attachment; filename="{download_name}"')
        self.send_header('Content-Length', str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    # ---------------- API ----------------
    def do_POST(self):
        path = urlparse(self.path).path
        body = self.json_body()

        if path == '/api/register':
            users = jload(USERS_PATH, {})
            email = (body.get('email') or '').strip().lower()
            if not email or '@' not in email or len(body.get('pass', '')) < 6 or len(body.get('name', '')) < 2:
                return self.send_json({'ok': False, 'error': 'Invalid registration data'}, 400)
            if email in users:
                return self.send_json({'ok': False, 'error': 'Account already exists'}, 400)
            users[email] = {'name': body['name'], 'pass': sha(body['pass'])}
            jsave(USERS_PATH, users)
            return self.send_json({'ok': True, 'name': body['name'], 'email': email})

        if path == '/api/login':
            users = jload(USERS_PATH, {})
            email = (body.get('email') or '').strip().lower()
            u = users.get(email)
            if not u or u.get('pass') != sha(body.get('pass', '')):
                return self.send_json({'ok': False, 'error': 'Invalid email or password'}, 401)
            return self.send_json({'ok': True, 'name': u['name'], 'email': email})

        if path == '/api/orders':
            orders = jload(ORDERS_PATH, [])
            order = body
            order.setdefault('id', 'NM-' + str(int(time.time())))
            order.setdefault('date', datetime.datetime.now().strftime('%b %d, %Y, %I:%M %p'))
            order.setdefault('status', 'paid')
            files = []
            for it in order.get('items', []):
                path_z, fname = generate_zip(order, it)
                files.append({'pid': it.get('pid'), 'name': fname, 'url': f"/api/deliveries/{order['id']}/{it.get('pid')}.zip"})
            order['files'] = files
            orders.insert(0, order)
            jsave(ORDERS_PATH, orders)
            return self.send_json({'ok': True, 'order': order, 'files': files})

        if path == '/api/receipt':
            order = body.get('order', {})
            to = body.get('to') or order.get('email', '')
            if not to:
                return self.send_json({'ok': False, 'error': 'Missing recipient'}, 400)
            base_url = body.get('base_url', '')
            result = send_receipt(to, order, base_url)
            return self.send_json({'ok': True, **result})

        return self.send_json({'ok': False, 'error': 'Unknown API'}, 404)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == '/api/config':
            c = cfg()
            return self.send_json({
                'merchant_name': c.get('merchant_name', 'NullMarket Digital Services'),
                'gcash_number': c.get('gcash_number', '+63 917 555 0123'),
                'maya_number': c.get('maya_number', '+63 918 555 0123'),
                'smtp_configured': bool(c.get('smtp_user') and c.get('smtp_pass')),
            })

        if path == '/api/orders':
            q = parsed.query
            user = ''
            for kv in q.split('&'):
                if kv.startswith('user='): user = unquote(kv[5:])
            orders = jload(ORDERS_PATH, [])
            if user:
                orders = [o for o in orders if o.get('user', '').lower() == user.lower()]
            return self.send_json({'ok': True, 'orders': orders})

        m = re.match(r'^/api/deliveries/([^/]+)/(\d+)\.zip$', path)
        if m:
            oid, pid = m.group(1), int(m.group(2))
            orders = jload(ORDERS_PATH, [])
            order = next((o for o in orders if o.get('id') == oid), None)
            if not order:
                return self.send_json({'ok': False, 'error': 'Order not found'}, 404)
            item = next((i for i in order.get('items', []) if i.get('pid') == pid), None)
            if not item:
                return self.send_json({'ok': False, 'error': 'Item not found'}, 404)
            zpath, fname = generate_zip(order, item)
            return self.send_file_attachment(zpath, fname)

        return super().do_GET()


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8080))
    print(f'NullMarket real backend running on http://0.0.0.0:{port}')
    print(f'  data dir : {DATA}')
    print(f'  smtp     : {"configured" if cfg().get("smtp_user") else "NOT configured (receipts saved to data/outbox)"}')
    HTTPServer(('0.0.0.0', port), Handler).serve_forever()
